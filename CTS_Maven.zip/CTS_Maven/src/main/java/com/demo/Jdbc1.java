package com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Jdbc1 {

	public static void main(String[] args) {
		Connection con;
		 try
	 	  {
	 		  Class.forName("com.mysql.jdbc.Driver");
	 		  
	 		  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/emp1","root","Roadie@1065");
	 		  Statement s = con.createStatement();
	 		  ResultSet rs=s.executeQuery("select * from emp1");
	 		  while(rs.next())
	 		  {
	 			  System.out.println(rs.getString(1));
	 			 System.out.println(rs.getString(2));
	 			 System.out.println(rs.getString(3));
	 		  }
	 	  }
		   catch(Exception e)
		  {
	 	 	 System.out.println("");
		  }

	}

}
